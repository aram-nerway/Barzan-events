# BARZAN EVENTS — website setup

The public site is `index.html`. It uses GitHub Pages for hosting and Supabase for live bookings, the decor gallery, image storage, and administrator authentication.

## 1. Create the Supabase project

1. Create a project at https://supabase.com/dashboard.
2. In **Project Settings → API**, copy the **Project URL** and the **anon / publishable key**.
3. Open **SQL Editor → New query**, paste all of `supabase/schema.sql`, and run it.
4. In **Authentication → Users**, add the administrator account using the admin email and a strong password.
5. In SQL Editor, run the following after replacing the email with the exact admin email you created:

```sql
insert into public.admin_users (user_id)
select id from auth.users where email = 'YOUR_ADMIN_EMAIL'
on conflict (user_id) do nothing;
```

## 2. Connect the website

Open `index.html` and replace these two values near the top of the JavaScript:

```js
const SUPABASE_URL = 'YOUR_SUPABASE_PROJECT_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
```

Use only the Supabase **anon / publishable** key in the browser. Never put the `service_role` or secret key in this repository or website.

## 3. Publish with GitHub Pages

1. Open this repository → **Settings → Pages**.
2. Under **Build and deployment**, select **Deploy from a branch**.
3. Choose branch `main`, folder `/(root)`, then **Save**.
4. Wait for the deployment. The public address should be `https://aram-nerway.github.io/Barzan-events/`.

GitHub Pages publishes the `index.html` file from the selected branch/folder. Changes pushed to that branch are published automatically.

## 4. Admin access

Open the public site and tap the small **ADMIN** link in the footer. Sign in with the administrator email/password created in Supabase. The admin can view bookings, change status, delete requests, and add/remove decor photos. Admin access is enforced by Supabase Auth and Row Level Security; hiding the admin link is not the security boundary.

## Important notes

- The booking calendar blocks dates with a pending or confirmed booking. Cancelling or deleting a booking releases that date.
- The public calendar endpoint returns dates only; customer names, phone numbers, and notes are private to authorized admins.
- Booking requests are stored in Supabase. Consider enabling email notifications or connecting a notification service after launch.
- Replace the sample gallery photos with actual BARZAN EVENTS photos using the admin panel.
